# SciHub Firefox

## Building
1. Install web-ext
```
$ npm install --global web-ext
```

2. Build
```
$ web-ext build
```

---
Source Code hosted at https://github.com/elasa-Sites/scihub-firefox
